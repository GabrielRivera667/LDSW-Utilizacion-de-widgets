package com.example.flutter_ldsw

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
